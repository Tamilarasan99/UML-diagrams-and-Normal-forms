

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class LifecycleServlet
 */
@WebServlet("/LifecycleServlet")
public class LifecycleServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    
    private ServletConfig config;

	   public LifecycleServlet() {
	      System.out.println("FirstServlet object is created..");
	   }

	  public void init(ServletConfig config) {
	       this.config = config;
	       System.out.println("init() method called");
	   
	  }
	   public void service(ServletRequest request, ServletResponse response) throws IOException {
	      System.out.println("service() method called");
	      PrintWriter out=response.getWriter();
	      out.println("this is a server program");
	   }
	   public void destroy() {
	      System.out.println("destroy() method called");
	   }
	   

	  public ServletConfig getServletConfig() {
	      System.out.println("getServletConfig() method called");
	      return config; 
	   }     

	   public String getServletInfo() {
	      System.out.println("getServletInfo() method called");
	      return "first servlet example";
	   }

}
