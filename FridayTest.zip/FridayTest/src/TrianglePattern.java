//15)A)	Java program to print the following patterns
public class TrianglePattern {
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int i,j,k,n=4,l=1;
		for(i=0;i<4;i++)
        {
        for(j=n-1;j>i;j--)
        {
         System.out.print(" ");
        }
       for(k=0;k<l;k++)
       {
       System.out.print(l-i);
	}
       l+=2;
       System.out.println();
}
}
}
