import java.util.Scanner;

public class CalculateTax {
	public static void main(String[] args)
	{
		int sal;
	
	int remsal;
	int tax;
	Scanner sc = new Scanner(System.in);
	sal = sc.nextInt();
	if (sal<50000)
	{System.out.println("no need to pay tax");
	}
	if(sal>50000&&sal<60000)
	{ remsal=sal-50000;
	 tax=remsal*10/100;
	System.out.println("tax to be paid is "+tax);
	}
	if(sal>60000&&sal<150000)
	{
	remsal=sal-60000;
	tax=remsal*20/100;
	System.out.println("tax to be paid is "+tax);
	}
	if(sal>150000)
	{
	tax=sal*30/100;
	System.out.println("tax to be paid is "+tax);
	}

}
}
