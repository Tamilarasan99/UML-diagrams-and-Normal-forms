import java.util.*;

//1)	Take the input of number from user and check number is Palindrome or not in Java.


public class Palindrome {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		 int n,r,sum=0,temp;    
		  Scanner sc = new Scanner(System.in);
		  System.out.println("Enter the number");
		  n = sc.nextInt();
		  temp=n;    
		  while(n>0){    
		   r=n%10;  //getting remainder  
		   sum=(sum*10)+r;    
		   n=n/10;    
		  }    
		  if(temp==sum)    
		   System.out.println("palindrome number ");    
		  else    
		   System.out.println("not palindrome");     
	}

}
