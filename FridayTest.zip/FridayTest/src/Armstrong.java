import java.util.Scanner;

//2)	create Java programs to check if the given number is an Armstrong number or not.
public class Armstrong {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int number,actual, remainder, result = 0;
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter the number");
		  number = sc.nextInt();
		  actual = number;

        while (actual != 0)
        {
            remainder = actual % 10;
            result = result + (remainder*remainder*remainder);
            actual = actual/10;
        }

        if(result == number)
            System.out.println(number + " is an Armstrong number.");
        else
            System.out.println(number + " is not an Armstrong number.");

	}

}
