//Write a Java Program to find the second-highest number in an array.
import java.util.Arrays;

public class SecondLargest {
	public static void main(String[] args) { 
	      int num[] = {1, 9, 5, 2, 8, -1, 3, 55}; 
	      int n = num.length;
	      Arrays.sort(num);
	       System.out.println("Second Highest Number: "+num[n-2]);
	 
	   }

}
