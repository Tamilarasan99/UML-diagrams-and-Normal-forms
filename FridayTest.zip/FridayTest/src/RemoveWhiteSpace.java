//Write a Java Program to remove all white spaces from a string.
import java.util.Scanner;

public class RemoveWhiteSpace {
	 public static void main(String[] args) {    
            Scanner sc = new Scanner(System.in);
            System.out.println(" Enter the Words");
	        String str1=sc.nextLine();        
	        str1 = str1.replaceAll("\\s+", "");       
	        System.out.println("String after removing all the white spaces : " + str1); 
	        sc.close();
	    }    

}
