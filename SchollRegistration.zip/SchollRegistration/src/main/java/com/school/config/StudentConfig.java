package com.school.config;

import javax.sql.DataSource;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.datasource.DriverManagerDataSource;
import org.springframework.web.servlet.config.annotation.EnableWebMvc;
import org.springframework.web.servlet.view.InternalResourceViewResolver;

@Configuration
@EnableWebMvc
@ComponentScan(basePackages = {"com.school.*","com.school.studentDao"})
public class StudentConfig {
	@Bean
	public  InternalResourceViewResolver viewResolver() {
		InternalResourceViewResolver viewResolver = new InternalResourceViewResolver();
		viewResolver.setPrefix("/WEB-INF/view/");
		viewResolver.setSuffix(".jsp");
		return viewResolver;
		
	}
	
	DataSource datainfo() {
		DriverManagerDataSource datainfo = new DriverManagerDataSource();
		datainfo.setUsername("root");
		datainfo.setPassword("1234");
		datainfo.setUrl("jdbc:mysql://localhost:3307/studentreg");
		datainfo.setDriverClassName("com.mysql.cj.jdbc.Driver");
		return datainfo;
	}
	
	@Bean
	public JdbcTemplate jdbcTemplate() {
	   JdbcTemplate jdbcTemplate = new JdbcTemplate(datainfo());
	   return jdbcTemplate;
	}

}
