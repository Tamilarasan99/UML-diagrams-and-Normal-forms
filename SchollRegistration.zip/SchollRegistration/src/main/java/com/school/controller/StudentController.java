package com.school.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.school.model.Student;
import com.school.studentDao.StudentDAO;

@Controller
public class StudentController {
	@Autowired
	StudentDAO stdDao;
	@GetMapping(value= "/register")
	public String showStudent(Model md) {
		Student std = new Student();
		md.addAttribute("Student",std);
		return "register";
	}
	@ResponseBody
	@PostMapping(value= "/save")
	public String saveStud(Student std) {
		stdDao.saveStudent(std);
		return "registered successfully";
	}

}
