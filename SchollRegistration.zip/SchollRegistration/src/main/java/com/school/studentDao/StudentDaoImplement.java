package com.school.studentDao;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import com.school.model.Student;
@Repository
public class StudentDaoImplement implements StudentDAO {
@Autowired
	private JdbcTemplate jdbcTemplate;
@Override
	public void saveStudent(Student stud) {
		// TODO Auto-generated method stub
		String sql="insert into student values(?,?,?,?)";
		jdbcTemplate.update(sql,stud.getId(),stud.getName(),stud.getAddress(),stud.getAge());
		
	}

	

}
