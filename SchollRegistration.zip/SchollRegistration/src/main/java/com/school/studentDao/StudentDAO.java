package com.school.studentDao;

import com.school.model.Student;

public interface StudentDAO {
	public void saveStudent(Student stud);

}
